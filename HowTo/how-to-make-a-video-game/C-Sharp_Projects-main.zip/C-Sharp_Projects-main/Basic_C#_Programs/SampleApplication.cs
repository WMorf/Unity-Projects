using System;

class SampleApplication
{
	static void Main()
    {
        Console.WriteLine("Hello, World!");
    }
}