﻿using System;


class Program
{
    static void Main()
    {
        Console.WriteLine("Welcome to Acme Accounting Systems! \nRemember, we\'re \"accounting\" on you!");
        Console.ReadLine();
    }
}

