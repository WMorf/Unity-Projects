﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassMethodAssignment
{
    public class Test
    {
        public void Half(int var1, out int varHalf)
        {
            varHalf = var1 / 2;
        }
    }

}
