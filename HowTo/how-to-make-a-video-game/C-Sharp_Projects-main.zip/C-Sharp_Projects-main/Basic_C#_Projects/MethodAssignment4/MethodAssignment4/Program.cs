﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MethodAssignment4
{
    class Program
    {
        static void Main(string[] args)
        {
            Voidpractice data = new Voidpractice();
            data.Nonsense(5, 12);
            data.Nonsense(var1: 7, var2: 9);
            Console.ReadLine();

        }
    }
}
