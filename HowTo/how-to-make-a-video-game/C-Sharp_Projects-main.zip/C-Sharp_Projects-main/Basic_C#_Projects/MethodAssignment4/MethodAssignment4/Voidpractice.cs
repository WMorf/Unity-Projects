﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MethodAssignment4
{
    class Voidpractice
    {
        public void Nonsense(int var1, int var2)
        {
            int result1 = var1 * 5;
            Console.WriteLine(var2);
        }
    }
}
