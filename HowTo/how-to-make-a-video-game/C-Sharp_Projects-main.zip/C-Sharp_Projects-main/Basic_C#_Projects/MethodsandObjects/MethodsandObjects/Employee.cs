﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MethodsandObjects
{
    public class Employee: Person
    {
        public int Id { get; set; }
    }
}
